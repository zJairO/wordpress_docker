<?php
namespace Rtrsp\Controllers\Admin\Meta;

class MetaOptions {  
    function __construct() {
        // tab option filter  
    }    
}