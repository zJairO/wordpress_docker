<?php

namespace Rtrsp\Helpers;

class Fns {
 
    public static function check_license() {
        return apply_filters('rtrs_check_license', true);
    } 
}
