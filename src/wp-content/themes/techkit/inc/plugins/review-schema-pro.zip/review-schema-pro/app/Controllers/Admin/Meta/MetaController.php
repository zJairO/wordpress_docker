<?php

namespace Rtrsp\Controllers\Admin\Meta;

class MetaController {
	public function __construct() { 
		new MetaOptions(); 
	}  
}