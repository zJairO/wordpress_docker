<?php if (!defined('FW')) die('Forbidden');

/**
 * Instances of this class will be created for extensions without class
 */
class FW_Extension_Default extends FW_Extension
{
	protected function _init()
	{
	}
}
